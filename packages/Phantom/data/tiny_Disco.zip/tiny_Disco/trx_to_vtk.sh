#!/bin/bash

#run tractseg to extract tracts and mask from DWI

my_path=/home/gui/Documents/Post-doc
path1=$my_path/data
path2=$my_path/data
path3=/home/gui/Anima-Public/build/bin
path4=$my_path/code/TractOT_workspace/packages/Preprocessing/src


SUBJECTS=(100 200)
TRACT=q

n=10
L=5

cd $path4/script
for SUBJECT in ${SUBJECTS[@]}
do
	uv run trx_to_vtk.py -i $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/6augmented_FA_nolift_${TRACT}_n${n}.trx -o $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/6augmented_FA_nolift_${TRACT}_n${n}.vtk &
	uv run trx_to_vtk.py -i $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/6augmented_MAS_nolift_${TRACT}_n${n}.trx -o $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/6augmented_MAS_nolift_${TRACT}_n${n}.vtk &
	uv run trx_to_vtk.py -i $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/7cores_FA_nolift_${TRACT}_L${L}_k1.trx -o $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/7cores_FA_nolift_${TRACT}_L${L}_k1.vtk &
	uv run trx_to_vtk.py -i $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/7cores_MAS_nolift_${TRACT}_L${L}_kNone.trx -o $path1/tiny_Disco/$SUBJECT/06-AugmentedTractsOT/7cores_MAS_nolift_${TRACT}_L${L}_kNone.vtk &
done
wait
