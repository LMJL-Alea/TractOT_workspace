#!/bin/bash

my_path=/home/gui/Documents/Post-doc
path1=$my_path/data
path2=$my_path/data
path3=/home/gui/Anima-Public/build/bin
path4=$my_path/code/TractOT_workspace/packages/TractOT/src
path5=$my_path/code/TractOT_workspace/packages/Phantom/src

dataset=tiny_Disco


$path3/animaDWISimulationFromMCM -i $path1/$dataset/200/03-MCM/my_mcm_ill.mcm -b $path1/$dataset/100/01-DWI/data100.bval -g $path1/$dataset/100/01-DWI/data100.bvec -o $path1/$dataset/200/01-DWI/data200.nii.gz -s 1 --small-delta 0.0121025 --big-delta 0.030045 

$path3/animaCollapseImage -i $path1/$dataset/200/01-DWI/data200.nii.gz -o $path1/$dataset/200/01-DWI/data200.nii.gz

$path3/animaDTIEstimator -i $path1/$dataset/200/01-DWI/data200.nii.gz -b $path1/$dataset/100/01-DWI/data100.bval -g $path1/$dataset/100/01-DWI/data100.bvec -o $path1/$dataset/200/07-DTI/DTI_200.nrrd

$path3/animaDTIScalarMaps -i $path1/$dataset/200/07-DTI/DTI_200.nrrd -f $path1/$dataset/200/07-DTI/FA_200.nrrd


