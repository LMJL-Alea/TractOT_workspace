#!/bin/bash

my_path=/home/gui/Documents/Post-doc
path1=$my_path/data
path2=$my_path/data
path3=/home/gui/Anima-Public/build/bin
path4=$my_path/code/TractOT_workspace/packages/TractOT/src
path5=$my_path/code/TractOT_workspace/packages/Phantom/src

dataset=tiny_Disco
SUBJECTS=(100 200)

TRACT=q
n=10




# ~~ FA ~~

name=FA_nolift

cd $path4/script/
for SUBJECT in ${SUBJECTS[@]}
do
	uv run scalar_to_tract.py -t $path1/$dataset/100/05-Tracts/2newgrid_${TRACT}_n${n}.vtk -o $path1/$dataset/$SUBJECT/06-AugmentedTractsOT/6augmented_${name}_${TRACT}_n${n}.trx -s $path1/$dataset/$SUBJECT/07-DTI/FA_${SUBJECT}.nrrd -c $path1/$dataset/100/03-MCM/spatial.nrrd -r ${path1}/$dataset/100/07-DTI/DTI_100.nii.gz &
done
wait

# ~~ MAS ~~
name=MAS_nolift
lift=False


uv run MCM_to_tract.py -t $path1/$dataset/100/05-Tracts/2newgrid_${TRACT}_n${n}.vtk -o $path1/$dataset/100/06-AugmentedTractsOT/6augmented_${name}_${TRACT}_n${n}.trx -c $path1/$dataset/100/03-MCM/my_mcm/my_mcm_ -w $path1/$dataset/100/03-MCM/my_mcm/my_mcm_weights.nrrd -s $path1/$dataset/100/03-MCM/spatial.nrrd -r ${path1}/$dataset/100/07-DTI/DTI_100.nii.gz -l $lift

uv run MCM_to_tract.py -t $path1/$dataset/100/05-Tracts/2newgrid_${TRACT}_n${n}.vtk -o $path1/$dataset/200/06-AugmentedTractsOT/6augmented_${name}_${TRACT}_n${n}.trx -c $path1/$dataset/200/03-MCM/my_mcm_ill/my_mcm_ill_ -w $path1/$dataset/200/03-MCM/my_mcm_ill/my_mcm_ill_weights.nrrd -s $path1/$dataset/100/03-MCM/spatial.nrrd -r ${path1}/$dataset/100/07-DTI/DTI_100.nii.gz -l $lift 


