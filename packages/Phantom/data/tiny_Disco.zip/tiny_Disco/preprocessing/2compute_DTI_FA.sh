#!/bin/bash

dataset=tiny_Disco
SUBJECT=100

path1=/home/gui/Documents/Post-doc/data/$dataset
path2=/home/gui/Anima-Public/build/bin


$path2/animaDTIEstimator -i $path1/$SUBJECT/01-DWI/data${SUBJECT}.nii.gz -b $path1/$SUBJECT/01-DWI/data${SUBJECT}.bval -g $path1/$SUBJECT/01-DWI/data${SUBJECT}.bvec -o $path1/$SUBJECT/07-DTI/DTI_100.nii.gz

$path2/animaDTIScalarMaps -i $path1/$SUBJECT/07-DTI/DTI_100.nii.gz -f $path1/$SUBJECT/07-DTI/FA_100.nrrd
