#!/bin/bash

#Compute MCM for different compartment then average

dataset=tiny_Disco
SUBJECT=100

path1=/home/gui/Documents/Post-doc/data/$dataset
path2=/home/gui/Anima-Public/build/bin

FASCICLE_TYPE=3 #2 zepp 3 tensor

$path2/animaMCMEstimator -F -c $FASCICLE_TYPE -n 3 -i $path1/$SUBJECT/01-DWI/data${SUBJECT}.nii.gz -b $path1/$SUBJECT/01-DWI/data${SUBJECT}.bval -g $path1/$SUBJECT/01-DWI/data${SUBJECT}.bvec -o $path1/$SUBJECT/03-MCM/my_mcm.mcm --optimizer levenberg --ml-mode 2

