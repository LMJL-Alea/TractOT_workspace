#!/bin/bash

SUBJECT=100
dataset=tiny_Disco
TRACT=q

path1=/home/gui/Documents/Post-doc/data/$dataset
path2=/home/gui/Anima-Public/build/bin
path3=/home/gui/Documents/Post-doc/code/TractOT_workspace/packages/Phantom/src

cd $path3/script/
uv run compute_most_colinear_image.py -p $path1/$SUBJECT/03-MCM/my_mcm/ -o $path1/$SUBJECT/03-MCM/my_mcm/ -t $path1/$SUBJECT/05-Tracts/1raw_${TRACT}.vtk -n $TRACT -r $path1/$SUBJECT/07-DTI/DTI_100.nii.gz -m my_mcm



