#!/bin/bash

dataset=tiny_Disco
SUBJECT=100

path1=/home/gui/Documents/Post-doc/data/$dataset
path2=/home/gui/Anima-Public/build/bin
path3=/home/gui/Documents/Post-doc/code/TractOT_workspace/packages/Phantom/src



TRACTS=(q r i)
dilation=1

for TRACT in ${TRACTS[@]}
do
	cd $path3/script/
	uv run compute_bundle_mask_from_streamlines.py -p $path1/$SUBJECT/05-Tracts/1raw_${TRACT}.vtk -o $path1/$SUBJECT/05-Tracts/mask/${TRACT} -e $path1/$SUBJECT/03-MCM/my_mcm/my_mcm_0.nrrd -c $path1/$SUBJECT/03-MCM/spatial.nrrd -d $dilation -r $path1/$SUBJECT/07-DTI/DTI_100.nii.gz
done

TRACT1=q
TRACT2=r
TRACT3=i

cd $path3/script
uv run compute_and_or_mask.py -m $path1/$SUBJECT/05-Tracts/mask/${TRACT1}.nrrd $path1/$SUBJECT/05-Tracts/mask/${TRACT2}.nrrd $path1/$SUBJECT/05-Tracts/mask/${TRACT3}.nrrd -o $path1/$SUBJECT/05-Tracts/mask/${TRACT1}_${TRACT2}_${TRACT3}

