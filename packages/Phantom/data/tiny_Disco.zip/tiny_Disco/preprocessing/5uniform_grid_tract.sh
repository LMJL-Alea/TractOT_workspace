#!/bin/bash

SUBJECT=100
dataset=tiny_Disco
TRACT=q

path1=/home/gui/Documents/Post-doc/data/$dataset
path2=/home/gui/Anima-Public/build/bin
path3=/home/gui/Documents/Post-doc/code/TractOT_workspace/packages/Phantom/src
path3=/home/gui/Documents/Post-doc/code/TractOT_workspace/packages/Preprocessing/src


n=10

cd $path3/script/
uv run uniform_grid_streamlines.py -i $path1/$SUBJECT/05-Tracts/1raw_${TRACT}.vtk -o $path1/$SUBJECT/05-Tracts/2newgrid_${TRACT}_n${n}.vtk -n $n -r $path1/100/07-DTI/DTI_100.nii.gz



