# Readme

The tiny_Disco dataset is an example for the TractOT pipeline. It is build one the top of the Disco dataset, the use of the Disco dataset was provided with the courtesy of Emmanuel Caruyer.

Please refer to the Disco information here:
- Original dataset:
https://data.mendeley.com/datasets/fgf86jdfg6/3

- Articles:
https://inserm.hal.science/inserm-03366969/file/1-s2.0-S2352340921007113-main.pdf
https://inria.hal.science/hal-04390592/file/1-s2.0-S1053811923003828-main.pdf


