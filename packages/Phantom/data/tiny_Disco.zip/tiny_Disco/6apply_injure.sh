#!/bin/bash

my_path=/home/gui/Documents/Post-doc
path1=$my_path/data
path2=$my_path/data
path3=/home/gui/Anima-Public/build/bin
path4=$my_path/code/TractOT_workspace/packages/TractOT/src
path5=$my_path/code/TractOT_workspace/packages/Phantom/src

dataset=tiny_Disco

w1=0.1
w2=0.01
w3=0.01
i1=1.1
t=0.1
i2=1.1



TRACT1=q
TRACT2=r
TRACT3=i


echo -e "$w1 $w2 $w3\n$i1 $i2\n$t" > $path1/$dataset/200/applied_injure.txt

mkdir $path1/$dataset/200/03-MCM/my_mcm_ill

cp  $path1/$dataset/100/03-MCM/my_mcm/my_mcm_0.nrrd $path1/$dataset/200/03-MCM/my_mcm_ill/my_mcm_ill_0.nrrd



cd $path5/script/ 

uv run apply_injure_isotropification.py -p $path1/$dataset/100/03-MCM/my_mcm/ -o $path1/$dataset/200/03-MCM/my_mcm_ill/ -m $path1/$dataset/100/05-Tracts/mask/${TRACT1}_${TRACT2}_${TRACT3}_and.nrrd -c $path1/$dataset/100/03-MCM/my_mcm/most_colinear_${TRACT1}.nrrd -t $t -n1 my_mcm -n2 my_mcm_ill

uv run apply_injure_colinear_to_free_water.py -p $path1/$dataset/100/03-MCM/my_mcm/ -o $path1/$dataset/200/03-MCM/my_mcm_ill/ -m $path1/$dataset/100/05-Tracts/mask/${TRACT1}_${TRACT2}_${TRACT3}_and.nrrd -c $path1/$dataset/100/03-MCM/my_mcm/most_colinear_${TRACT1}.nrrd -w $w1 -n1 my_mcm -n2 my_mcm_ill

uv run apply_injure_reduced_signal.py -p $path1/$dataset/200/03-MCM/my_mcm_ill/ -o $path1/$dataset/200/03-MCM/my_mcm_ill/ -m $path1/$dataset/100/05-Tracts/mask/${TRACT1}_start.nrrd -c $path1/$dataset/100/03-MCM/my_mcm/most_colinear_${TRACT1}.nrrd -i $i2 -n1 my_mcm_ill -n2 my_mcm_ill 

uv run apply_injure_colinear_to_isotropification.py -p $path1/$dataset/200/03-MCM/my_mcm_ill/ -o $path1/$dataset/200/03-MCM/my_mcm_ill/ -m $path1/$dataset/100/05-Tracts/mask/${TRACT1}_${TRACT2}_${TRACT3}_and.nrrd -c $path1/$dataset/100/03-MCM/my_mcm/most_colinear_${TRACT1}.nrrd -w $w2 -n1 my_mcm_ill -n2 my_mcm_ill

uv run apply_injure_colinear_to_reduced_signal.py -p $path1/$dataset/200/03-MCM/my_mcm_ill/ -o $path1/$dataset/200/03-MCM/my_mcm_ill/ -m $path1/$dataset/100/05-Tracts/mask/${TRACT1}_start.nrrd -c $path1/$dataset/100/03-MCM/my_mcm/most_colinear_${TRACT1}.nrrd -w $w3 -i $i1 -n1 my_mcm_ill -n2 my_mcm_ill 



echo -e "<?xml version="1.0"?>
<Model>
<Weights>my_mcm_ill_weights.nrrd</Weights>
<Compartment>
<Type>FreeWater</Type>
<FileName>my_mcm_ill_0.nrrd</FileName>
</Compartment>
<Compartment>
<Type>Tensor</Type>
<FileName>my_mcm_ill_1.nrrd</FileName>
</Compartment>
<Compartment>
<Type>Tensor</Type>
<FileName>my_mcm_ill_2.nrrd</FileName>
</Compartment>
<Compartment>
<Type>Tensor</Type>
<FileName>my_mcm_ill_3.nrrd</FileName>
</Compartment>
<Compartment>
<Type>Tensor</Type>
<FileName>my_mcm_ill_4.nrrd</FileName>
</Compartment>
<Compartment>
<Type>Tensor</Type>
<FileName>my_mcm_ill_5.nrrd</FileName>
</Compartment>
</Model>" > $path1/$dataset/200/03-MCM/my_mcm_ill.mcm
